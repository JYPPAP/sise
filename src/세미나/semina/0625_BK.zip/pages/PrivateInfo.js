import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

function PrivateInfo() {
  return (
    <View>
      <View>
        <Text>개인정보 보호방침 입니다.</Text>
      </View>
    </View>
  );
}

export default PrivateInfo;
