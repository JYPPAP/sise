import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

function Games() {
  return (
    <View testId="game_page">
      <View>
        <Text>게임 목록 입니다.</Text>
      </View>
    </View>
  );
}

export default Games;
