import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

function Servers() {
  return (
    <View  testId="main_page">
      <Text>서버 목록 입니다.</Text>
    </View>
  );
}
export default Servers;
