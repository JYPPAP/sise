import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

function Setting() {
  return (
    <View>
      <View>
        <Text>설정 페이지 입니다.</Text>
      </View>
    </View>
  );
}

export default Setting;
