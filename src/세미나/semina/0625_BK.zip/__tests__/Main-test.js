import 'react-native';
import React from 'react';
import {fireEvent, render, waitFor} from '@testing-library/react-native';
import {Main} from './Main';

describe('App test...', () => {
  test('TEST', async () => {
    const {getByTestId, getByText, queryBtTestId} = render(<Main />);
    const changeToRankList = getByTestId('changeToRankList');
  });
});
