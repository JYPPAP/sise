import 'react-native';
import React from 'react';
import {fireEvent, render, waitFor} from '@testing-library/react-native';
import {App} from '../App';

describe('App test...', () => {
  test('TEST', async () => {
    const {getByTestId, getByText, queryBtTestId} = render(<App />);
  });
});
